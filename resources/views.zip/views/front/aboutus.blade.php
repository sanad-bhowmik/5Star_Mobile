@extends('layouts.front')
@section('content')

             
       
        <div class="container mt-15">
        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-0.jpg')}}">
        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-1.jpg')}}">
        
        
        <img src="{{asset('assets/images/about/153f4adf24cdfae9e1c40dc6d6fbe0bb-1.jpg')}}">
       
       
        <img src="{{asset('assets/images/about/153f4adf24cdfae9e1c40dc6d6fbe0bb-1.jpg')}}">

        <img src="{{asset('assets/images/about/153f4adf24cdfae9e1c40dc6d6fbe0bb-2.jpg')}}">

        <img src="{{asset('assets/images/about/153f4adf24cdfae9e1c40dc6d6fbe0bb-3.jpg')}}">

        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-4.jpg')}}">

        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-5.jpg')}}">

        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-6.jpg')}}">

        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-7.jpg')}}">

        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-8.jpg')}}">

        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-9.jpg')}}">

        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-10.jpg')}}">
        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-11.jpg')}}"> 
        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-12.jpg')}}">
        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-13.jpg')}}">
        <img src="{{asset('assets/images/about/09181e101660185f856ccea1427bb0e4-14.jpg')}}">




        </div>

@endsection